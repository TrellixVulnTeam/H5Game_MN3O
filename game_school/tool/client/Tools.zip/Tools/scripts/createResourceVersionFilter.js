/**
 * Created by egret on 15-4-20.
 */
var filterConfig = [
    "resource/resource_version.json",
];

exports.filterConfig = filterConfig;