#ifndef PW_GDB_GENERATOR_H
#define PW_GDB_GENERATOR_H

#include "pw_gdb_idl.h"

namespace gdb
{
    class TableGenerator
    {
        enum
        {
            T_NIL,T_I32,T_I64,T_STR,T_BUF,T_DEC,T_ARRAY,
        };
    public:
        void gen(Table* t,const std::string& outputdir);
	public:
		Table* findTable(const std::string& name);
    protected:
        void genHpp(Table* t,const std::string& outputdir);
        void genHppFields(Table* t);
        void genHppFieldsGetterSetter(Table* t);
    protected:
        void genCpp(Table* t,const std::string& outputdir);
        void genCppFieldsBsonOpers(Table* t);
        void genCppFieldsGetterSetter(Table* t);
    protected:
        std::string getStoreTypeName(Field& r);
        std::string getStoreElementTypeName(Field& r);
        std::string getGetterTypeName(Field& r);
        std::string getSetterTypeName(Field& r);
        std::string getTypeNameDefaultValue(Field& r);
        std::string getMemberName(Field& r);
        int getBaseType(Field& r);
	protected:
		void genClear(const std::string& tabs,Field& r);
    protected:
        void writeLinesToFile(const std::string& filename);
    protected:
        std::vector<std::string> m_lines;
	public:
		std::vector<Table*> m_vAllTables;
    };
}
#endif // PW_GDB_GENERATOR_H
