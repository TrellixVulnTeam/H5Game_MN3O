#include "pw_gdb_generator.h"
#include "pw_gdb_parser.h"
#include "stdio.h"
#include <assert.h>

namespace gdb
{
    std::string tabX(int i)
    {
        std::string result;
        while(i--)
            result.append("\t");
        return result;
    }

    void TableGenerator::gen(Table* t,const std::string& outputdir)
    {
        this->genHpp(t,outputdir);
        this->genCpp(t,outputdir);
    }

    void TableGenerator::genHpp(Table* t,const std::string& outputdir)
    {
        m_lines.clear();
        m_lines.push_back(std::string("#ifndef _pw_orm_") + stringToLower(t->name) + "_");
        m_lines.push_back(std::string("#define _pw_orm_") + stringToLower(t->name) + "_");
		m_lines.push_back("");
        m_lines.push_back("#include \"pw_def.h\"");
        m_lines.push_back("#include \"pw_fixed_string.h\"");
        m_lines.push_back("#include \"pw_kvorm.h\"");
        m_lines.push_back("#include \"bson/bson.h\"");
        m_lines.push_back("#include \"bson/bsonobjbuilder.h\"");

        m_lines.push_back("");
        m_lines.push_back("namespace orm");
        m_lines.push_back("{");
		m_lines.push_back("");

		for(size_t i = 0; i < t->fields.size(); ++i)
		{
			Field& r = *(t->fields[i]);
			if(r.isTable())
			{
				Attrs* attr = r.find("meta");
				assert(attr && attr->args.size() > 0);

				if(findTable(attr->args[0]) == NULL)
				{
					printf("%s unknown table %s\n",__FUNCTION__,attr->args[0].c_str());
					exit(1);
				}

				m_lines.push_back(tabX(1) + "class " + attr->args[0] + ";");
			}
		}

		m_lines.push_back("");

		m_lines.push_back(tabX(1) + "class " + t->name + " : public pwutils::KvormBase");
        m_lines.push_back(tabX(1) + "{");
        m_lines.push_back(tabX(1) + "public:");
        m_lines.push_back(tabX(2) + "enum {");

        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *(t->fields[i]);
            m_lines.push_back(tabX(3) + "FIELD_" + stringToUpper(r.name) + ",");
        }
        m_lines.push_back(tabX(2) + "};");

        m_lines.push_back(tabX(1) + "public:");
        m_lines.push_back(tabX(2) + t->name + "();");
		m_lines.push_back(tabX(2) + "virtual ~" + t->name + "();");
        m_lines.push_back(tabX(1) + "public:");
        m_lines.push_back(tabX(2) + "void to_bson(std::string& buf); // override");
		m_lines.push_back(tabX(2) + "void to_bson(bson::bo& obj);");
        m_lines.push_back(tabX(2) + "void from_bson(const char* data,size_t size); // override");
		m_lines.push_back(tabX(2) + "void from_bson(bson::bo obj);");
		m_lines.push_back(tabX(2) + "void from_bson(bson::be elem);");


        m_lines.push_back(tabX(1) + "public:");
        m_lines.push_back(tabX(2) + "virtual int32 GetI32(unsigned field); // override");
        m_lines.push_back(tabX(2) + "virtual int64 GetI64(unsigned field); // override");
        m_lines.push_back(tabX(2) + "virtual const char* GetStr(unsigned field); // override");
        m_lines.push_back(tabX(2) + "virtual double GetDec(unsigned field); // override");
		m_lines.push_back(tabX(2) + "virtual pwutils::KvormBuffer GetBuf(unsigned field); // override");

        m_lines.push_back(tabX(1) + "public:");
        this->genHppFieldsGetterSetter(t);
        m_lines.push_back(tabX(1) + "protected:");
        this->genHppFields(t);
        m_lines.push_back(tabX(1) + "};");
        m_lines.push_back("}");
        m_lines.push_back("");
        m_lines.push_back(std::string("#endif // _pw_orm_") + stringToLower(t->name) + "_");

        this->writeLinesToFile(outputdir + "/pw_orm_" + stringToLower(t->name) + ".h");
    }

    void TableGenerator::genHppFieldsGetterSetter(Table* t)
    {
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *(t->fields[i]);

            if(!r.isArray())
            {
                m_lines.push_back(tabX(2) + getGetterTypeName(r) + " get_" + r.lowername + "();");
            }
            else
            {
                m_lines.push_back(tabX(2) + "const " + getStoreTypeName(r) + "& get_" + r.name+ "();");
                m_lines.push_back(tabX(2) + getGetterTypeName(r) + " get_" + r.lowername + "(size_t index);");
            }
        }

        m_lines.push_back("");

        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *(t->fields[i]);
            if(!r.isArray())
            {
                m_lines.push_back(tabX(2) + "void set_" + r.lowername + "(" + getSetterTypeName(r) + " value);");
            }
            else
            {
				m_lines.push_back("");
                m_lines.push_back(tabX(2) + "void " + r.lowername + "_push(" + getSetterTypeName(r) + " value);");
                m_lines.push_back(tabX(2) + "void " + r.lowername + "_size();");
                m_lines.push_back(tabX(2) + "void " + r.lowername + "_clear();");
                m_lines.push_back(tabX(2) + "void " + r.lowername + "_erase(size_t index);");
                m_lines.push_back(tabX(2) + "void " + r.lowername + "_reset(const " + getStoreTypeName(r) + "& array);");
                m_lines.push_back(tabX(2) + "void " + r.lowername + "_set(size_t index," + getSetterTypeName(r) + " value);");
				m_lines.push_back("");
            }
        }
    }

    void TableGenerator::genHppFields(Table* t)
    {
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *(t->fields[i]);
            m_lines.push_back(tabX(2) + getStoreTypeName(r) + " m_" + r.lowername + ";");
        }
    }

    void TableGenerator::writeLinesToFile(const std::string& filename)
    {
        FILE* f = fopen(filename.c_str(),"wb+");
        if(f == NULL)
            return ;

        for(size_t i = 0; i < m_lines.size(); ++i)
        {
            std::string& r = m_lines[i];
            fwrite(r.c_str(),r.length(),1,f);
            fwrite("\r\n",2,1,f);
        }
        fclose(f);
    }

    std::string TableGenerator::getStoreElementTypeName(Field& r)
    {
        std::string type = r.type;
        if(r.type == "string")
        {
            Attrs* attr = r.find("len");
            if(attr == NULL || attr->args.size() != 1)
                type = "std::string";
            else
                type = std::string("pwutils::fixed_string<") + attr->args[0] + ">";
        }
        else if(r.type == "bytes")
            type = "std::string";
		else if(r.type == "table")
		{
			Attrs* attr = r.find("meta");
			assert(attr && attr->args.size() > 0);
			type = attr->args[0] + "*";
		}
        return type;
    }

    std::string TableGenerator::getStoreTypeName(Field& r)
    {
        std::string type = getStoreElementTypeName(r);

		if(r.isArray())
        {
            type = std::string("std::deque< ") + type + " >";
        }
        return type;
    }

    std::string TableGenerator::getGetterTypeName(Field& r)
    {
        if(r.type == "string")
        {
            Attrs* attr = r.find("len");
            if(attr == NULL || attr->args.size() != 1)
                return "const std::string&";
            else
                return "const char*";

        }
        else if(r.type == "bytes")
			return "pwutils::KvormBuffer";
		else if(r.type == "table")
		{
			Attrs* attr = r.find("meta");
			assert(attr && attr->args.size() > 0);
			return attr->args[0] + "*";
		}
        return r.type;
    }

    std::string TableGenerator::getSetterTypeName(Field& r)
    {
        if(r.type == "string")
        {
            Attrs* attr = r.find("len");
            if(attr == NULL || attr->args.size() != 1)
                return "const std::string&";
            else
                return "const char*";
        }
        else if(r.type == "bytes")
            return "const pwutils::KvormBuffer&";
		else if(r.type == "table")
		{
			Attrs* attr = r.find("meta");
			assert(attr && attr->args.size() > 0);
			return attr->args[0] + "*";
		}

        return r.type;
    }

    std::string TableGenerator::getTypeNameDefaultValue(Field& r)
    {
        Attrs* defaultAttr = r.find("default");
        if(defaultAttr != NULL && defaultAttr->args.size() == 1)
            return defaultAttr->args[0];

        if(r.type.find("int") != std::string::npos)
            return "0";
        if(r.type.find("float") != std::string::npos)
            return "0.0f";

        if(r.type.find("double") != std::string::npos)
            return "0.0f";
        return "";
    }

    int TableGenerator::getBaseType(Field& r)
    {
        if(r.isArray())
            return T_ARRAY;
        if(r.type == "string")
            return T_STR;
        if(r.type == "int32")
            return T_I32;
        if(r.type == "int64")
            return T_I64;
        if(r.type == "float" || r.type == "double")
            return T_DEC;
        if(r.type == "bytes")
            return T_BUF;
        return T_NIL;
    }

    std::string TableGenerator::getMemberName(Field& r)
    {
        return std::string("m_").append(r.lowername);
    }

    void TableGenerator::genCpp(Table* t,const std::string& outputdir)
    {
        m_lines.clear();
        m_lines.push_back("#include \"pw_orm_" + stringToLower(t->name) + ".h\"");
        m_lines.push_back("#include \"pw_bsontocpp.h\"");
		m_lines.push_back("#include \"pw_logger.h\"");
		m_lines.push_back("#include \"pw_utils.h\"");

		for(size_t i = 0; i < t->fields.size(); ++i)
		{
			Field& r = *t->fields[i];
			std::string metaTableName = r.getMetaTableName();
			if(metaTableName.length() > 0)
			{
				m_lines.push_back("#include \"pw_orm_" + stringToLower(metaTableName) + ".h\"");
			}
		}

        m_lines.push_back("");
        m_lines.push_back("namespace orm");
        m_lines.push_back("{");
        m_lines.push_back("");

        // ����
		{
			m_lines.push_back(tabX(1) + t->name + "::" + t->name + "()");

			size_t num = 0;
			for(size_t i = 0; i < t->fields.size(); ++i)
			{
				Field& r = *t->fields[i];
				std::string defaultValue = getTypeNameDefaultValue(r);

				if(defaultValue.length() > 0)
				{
					if(num == 0)
						m_lines.push_back(tabX(2) + ": " + getMemberName(r) + "(" + defaultValue + ")");
					else
						m_lines.push_back(tabX(2) + ", " + getMemberName(r) + "(" + defaultValue + ")");
					++num;
				}
			}
			m_lines.push_back(tabX(1) + "{");

			for(size_t i = 0; i < t->fields.size(); ++i)
			{
				Field& r = *t->fields[i];
				std::string metaTableName = r.getMetaTableName();
				if(metaTableName.length() > 0 && !r.isArray())
				{
					m_lines.push_back(tabX(2) + getMemberName(r) + " = new " + metaTableName + "();");
				}
			}
			m_lines.push_back(tabX(1) + "}");
		}

		m_lines.push_back("");

		// ����
		{
			m_lines.push_back(tabX(1) + t->name + "::~" + t->name + "()");
			m_lines.push_back(tabX(1) + "{");
			for(size_t i = 0; i < t->fields.size(); ++i)
			{
				Field& r = *t->fields[i];
				std::string metaTableName = r.getMetaTableName();
				if(metaTableName.length() > 0)
				{
					if(!r.isArray())
					{
						m_lines.push_back(tabX(2) + + "_safe_delete(" + getMemberName(r) + ");");
					}
					else
					{
						genClear(tabX(2),r);
					}
				}
			}
			m_lines.push_back(tabX(1) + "}");
		}

        m_lines.push_back("");

        this->genCppFieldsBsonOpers(t);
        this->genCppFieldsGetterSetter(t);

        m_lines.push_back("}");

        this->writeLinesToFile(outputdir + "/pw_orm_" + stringToLower(t->name) + ".cpp");
    }

    void TableGenerator::genCppFieldsBsonOpers(Table* t)
    {
        // ----------------------------------------to_bson -----------------------------------

        m_lines.push_back(tabX(1) + "void " + t->name + "::to_bson(std::string& buf)");
        m_lines.push_back(tabX(1) + "{");
		m_lines.push_back(tabX(2) + "bson::bo obj;");
		m_lines.push_back(tabX(2) + "to_bson(obj);");
		m_lines.push_back(tabX(2) + "buf = std::string(obj.objdata(),obj.objsize());");
		m_lines.push_back(tabX(1) + "}");
		m_lines.push_back("");


		m_lines.push_back(tabX(1) + "void " + t->name + "::to_bson(bson::bo& obj)");
		m_lines.push_back(tabX(1) + "{");

		m_lines.push_back(tabX(2) + "mongo::BSONObjBuilder builder;");
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *t->fields[i];
            std::string lowname = r.lowername;
			std::string varname(lowname + "_buf");

            if(!r.isArray())
            {
				if(r.isTable())
				{
					std::string objname(lowname + "_obj");
					m_lines.push_back(tabX(2) + "{");
					m_lines.push_back(tabX(3) + "bson::bo " + objname + ";");
					m_lines.push_back(tabX(3) + getMemberName(r) + "->to_bson(" + objname + ");");
					m_lines.push_back(tabX(3) + "builder.append(\"" + lowname + +"\"," + objname + ");");
					m_lines.push_back(tabX(2) + "}");
				}
                else
				{
					m_lines.push_back(tabX(2) + "builder.append(\"" + lowname + +"\"," + getMemberName(r) + ");");
				}
            }
            else
            {
                m_lines.push_back("");
                m_lines.push_back(tabX(2) + "mongo::BSONArrayBuilder " + varname + ";");
                m_lines.push_back(tabX(2) + "for(size_t i = 0; i < " + getMemberName(r) + ".size(); ++i)");
                m_lines.push_back(tabX(2) + "{");

				if(r.isTable())
				{
					std::string objname(lowname + "_obj");
					m_lines.push_back(tabX(3) + "bson::bo " + objname + ";");
					m_lines.push_back(tabX(3) + getMemberName(r) + "[i]->to_bson(" + objname + ");");
					m_lines.push_back(tabX(3) + varname + ".append(" + objname + ");");
				}
				else
				{
					m_lines.push_back(tabX(3) + varname + ".append(" + getMemberName(r) + "[i]);");
				}
                m_lines.push_back(tabX(2) + "}");
                m_lines.push_back(tabX(2) + "builder.appendArray(\"" + lowname + +"\"," + varname + ".obj());");
                m_lines.push_back("");
            }
        }
        m_lines.push_back(tabX(2) + "obj = builder.obj();");
        m_lines.push_back(tabX(1) + "}");

        // -------------------------------------from_bson---------------------------------------

        m_lines.push_back("");

        m_lines.push_back(tabX(1) + "void " + t->name + "::from_bson(const char* data,size_t size)");
        m_lines.push_back(tabX(1) + "{");
		m_lines.push_back(tabX(2) + "mongo::BSONObj obj(data);");
		m_lines.push_back(tabX(2) + "from_bson(obj);");
		m_lines.push_back(tabX(1) + "}");
		m_lines.push_back(tabX(1) + "");

		m_lines.push_back(tabX(1) + "void " + t->name + "::from_bson(bson::be elem)");
		m_lines.push_back(tabX(1) + "{");
		m_lines.push_back(tabX(2) + "from_bson(elem.Obj());");
		m_lines.push_back(tabX(1) + "}");
		m_lines.push_back(tabX(1) + "");
		


		m_lines.push_back(tabX(1) + "void " + t->name + "::from_bson(bson::bo obj)");
		m_lines.push_back(tabX(1) + "{");
        m_lines.push_back(tabX(2) + "mongo::BSONObjIterator iter(obj);");
        m_lines.push_back(tabX(2) + "while(iter.more())");
        m_lines.push_back(tabX(2) + "{");
        m_lines.push_back(tabX(3) + "mongo::BSONElement e = iter.next();");
        m_lines.push_back(tabX(3) + "const char* fieldName = e.fieldName();");


        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *t->fields[i];
            std::string lowname = r.lowername;
            if(i == 0)
                m_lines.push_back(tabX(3) + "if(strcmp(fieldName,\"" + lowname + "\") == 0");
            else
                m_lines.push_back(tabX(3) + "else if(strcmp(fieldName,\"" + lowname + "\") == 0");

            std::vector<std::string> oldnames = r.getOldNames();
            for(size_t k = 0; k < oldnames.size(); ++k)
            {
                std::string oldname(stringToLower(oldnames[k]));
                m_lines.push_back(tabX(4) + " || strcmp(fieldName,\"" +oldname + "\") == 0");
            }
            m_lines[m_lines.size()-1] += ")";

            if(!r.isArray())
            {
				if(r.isTable())
					m_lines.push_back(tabX(4) + getMemberName(r) + "->from_bson(e);");
				else
	                m_lines.push_back(tabX(4) + "pwutils::bsonToCppVariable(" + getMemberName(r) + ",e);");
            }
            else
            {
                m_lines.push_back(tabX(3) + "{");
				if(r.isTable())
					genClear(tabX(4),r);
				else
					m_lines.push_back(tabX(4) + this->getMemberName(r) + ".clear();");
                m_lines.push_back(tabX(4) + "mongo::BSONObj aobj = e.Obj();");
                m_lines.push_back(tabX(4) + "mongo::BSONObjIterator aiter(aobj);");
                m_lines.push_back(tabX(4) + "while(aiter.more())");
                m_lines.push_back(tabX(4) + "{");
                m_lines.push_back(tabX(5) + "mongo::BSONElement ae = aiter.next();");
				if(!r.isTable())
				{
					m_lines.push_back(tabX(5) + getStoreElementTypeName(r) + " tmpvar;");
					m_lines.push_back(tabX(5) + "pwutils::bsonToCppVariable(tmpvar,ae);");
				}
				else
				{
					m_lines.push_back(tabX(5) + getStoreElementTypeName(r) + " tmpvar = new " + r.getMetaTableName() + "();");
					m_lines.push_back(tabX(5) + "tmpvar->from_bson(ae);");
				}
				m_lines.push_back(tabX(5) + this->getMemberName(r) + ".push_back(tmpvar);");
                m_lines.push_back(tabX(4) + "}");
                m_lines.push_back(tabX(3) + "}");
            }

        }

        m_lines.push_back(tabX(2) + "}");
        m_lines.push_back(tabX(1) + "}");

        m_lines.push_back("");

        // -------------------------------------------------------------------------

        m_lines.push_back(tabX(1) + "int32 " + t->name + "::GetI32(unsigned field) // override");
        m_lines.push_back(tabX(1) + "{");
        m_lines.push_back(tabX(2) + "switch(field)");
        m_lines.push_back(tabX(2) + "{");
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *t->fields[i];
            int type = this->getBaseType(r);
            if(type == T_I32)
            {
                m_lines.push_back(tabX(2) + "case FIELD_" + stringToUpper(r.name) + ":");
                m_lines.push_back(tabX(3) + "return this->get_" + r.lowername + "();");
            }
        }
		m_lines.push_back(tabX(2) + "case 0x7FFFFFFF:");
		m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "default:");
        m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "}");
        m_lines.push_back(tabX(2) + "return 0;");
        m_lines.push_back(tabX(1) + "}");
        m_lines.push_back("");


        // -------------------------------------------------------------------------
        m_lines.push_back(tabX(1) + "int64 " + t->name + "::GetI64(unsigned field) // override");
        m_lines.push_back(tabX(1) + "{");
        m_lines.push_back(tabX(2) + "switch(field)");
        m_lines.push_back(tabX(2) + "{");
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *t->fields[i];
            int type = this->getBaseType(r);
            if(type == T_I64)
            {
                m_lines.push_back(tabX(2) + "case FIELD_" + stringToUpper(r.name) + ":");
                m_lines.push_back(tabX(3) + "return this->get_" + r.lowername + "();");
            }
        }
		m_lines.push_back(tabX(2) + "case 0x7FFFFFFF:");
		m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "default:");
        m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "}");
        m_lines.push_back(tabX(2) + "return 0;");
        m_lines.push_back(tabX(1) + "}");
        m_lines.push_back("");

        // -------------------------------------------------------------------------
        m_lines.push_back(tabX(1) + "const char* " + t->name + "::GetStr(unsigned field) // override");
        m_lines.push_back(tabX(1) + "{");
        m_lines.push_back(tabX(2) + "switch(field)");
        m_lines.push_back(tabX(2) + "{");
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *t->fields[i];
            int type = this->getBaseType(r);
			
			if(type == T_STR)
            {
                m_lines.push_back(tabX(2) + "case FIELD_" + stringToUpper(r.name) + ":");
                m_lines.push_back(tabX(3) + "return this->" + getMemberName(r) + ".c_str();");
            }
        }
		m_lines.push_back(tabX(2) + "case 0x7FFFFFFF:");
		m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "default:");
        m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "}");
        m_lines.push_back(tabX(2) + "return \"\";");
        m_lines.push_back(tabX(1) + "}");
        m_lines.push_back("");

        // -------------------------------------------------------------------------

        m_lines.push_back(tabX(1) + "double " + t->name + "::GetDec(unsigned field) // override");
        m_lines.push_back(tabX(1) + "{");
        m_lines.push_back(tabX(2) + "switch(field)");
        m_lines.push_back(tabX(2) + "{");
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *t->fields[i];
            int type = this->getBaseType(r);
            if(type == T_DEC)
            {
                m_lines.push_back(tabX(2) + "case FIELD_" + stringToUpper(r.name) + ":");
                m_lines.push_back(tabX(3) + "return this->get_" + r.lowername + "();");
            }
        }
		m_lines.push_back(tabX(2) + "case 0x7FFFFFFF:");
		m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "default:");
        m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "}");
        m_lines.push_back(tabX(2) + "return 0;");
        m_lines.push_back(tabX(1) + "}");
        m_lines.push_back("");

        // -------------------------------------------------------------------------

        m_lines.push_back(tabX(1) + "pwutils::KvormBuffer " + t->name + "::GetBuf(unsigned field) // override");
        m_lines.push_back(tabX(1) + "{");
        m_lines.push_back(tabX(2) + "switch(field)");
        m_lines.push_back(tabX(2) + "{");
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *t->fields[i];
            int type = this->getBaseType(r);
            if(type == T_BUF)
            {
                m_lines.push_back(tabX(2) + "case FIELD_" + stringToUpper(r.name) + ":");
                m_lines.push_back(tabX(3) + "return this->get_" + r.lowername + "();");
            }
        }
		m_lines.push_back(tabX(2) + "case 0x7FFFFFFF:");
		m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "default:");
        m_lines.push_back(tabX(3) + "pwasserte(false && \"invalid field index\");");
        m_lines.push_back(tabX(2) + "}");
        m_lines.push_back(tabX(2) + "return pwutils::KvormBuffer();");
        m_lines.push_back(tabX(1) + "}");
        m_lines.push_back("");

        // -------------------------------------------------------------------------

    }

    void TableGenerator::genCppFieldsGetterSetter(Table* t)
    {
        for(size_t i = 0; i < t->fields.size(); ++i)
        {
            Field& r = *t->fields[i];

            if(!r.isArray())
            {
                if(r.type != "bytes")
                {
                    m_lines.push_back(tabX(1) + getGetterTypeName(r) + " " + t->name + "::get_" + r.lowername + "()");
                    m_lines.push_back(tabX(1) + "{");
                    m_lines.push_back(tabX(2) + "return " + getMemberName(r) + ";");
                    m_lines.push_back(tabX(1) + "}");
                    m_lines.push_back("");

                    m_lines.push_back(tabX(1) + "void " + t->name + "::set_" + r.lowername + "(" + this->getSetterTypeName(r) + " value)");
                    m_lines.push_back(tabX(1) + "{");
					if(r.isTable())
					{
						m_lines.push_back(tabX(2) + "pwassert(" + getMemberName(r) + " != value);");
						m_lines.push_back(tabX(2) + "_safe_delete(" + getMemberName(r) + ");");
					}
                    m_lines.push_back(tabX(2) + getMemberName(r) + " = value;");
                    m_lines.push_back(tabX(1) + "}");
                    m_lines.push_back("");
                }
                else
                {
                    m_lines.push_back(tabX(1) + getGetterTypeName(r) + " " + t->name + "::get_" + r.lowername + "()");
                    m_lines.push_back(tabX(1) + "{");
                    m_lines.push_back(tabX(2) + "return pwutils::KvormBuffer((char*)" + getMemberName(r) + ".c_str()," + getMemberName(r) + ".length());");
                    m_lines.push_back(tabX(1) + "}");
                    m_lines.push_back("");

                    m_lines.push_back(tabX(1) + "void " + t->name + "::set_" + r.lowername + "(" + this->getSetterTypeName(r) + " value)");
                    m_lines.push_back(tabX(1) + "{");
                    m_lines.push_back(tabX(2) + getMemberName(r) + ".clear();");
                    m_lines.push_back(tabX(2) + getMemberName(r) + ".append(value.buf,value.len);");
                    m_lines.push_back(tabX(1) + "}");
                    m_lines.push_back("");
                }
            }
            else
            {
                m_lines.push_back(tabX(1) + "const " + getStoreTypeName(r) + "& " + t->name + "::get_" + r.lowername + "()");
                m_lines.push_back(tabX(1) + "{");
                m_lines.push_back(tabX(2) + "return " + getMemberName(r) + ";");
                m_lines.push_back(tabX(1) + "}");
                m_lines.push_back("");
                m_lines.push_back(tabX(1) + getGetterTypeName(r) + " " + t->name + "::get_" + r.lowername + "(size_t index)");
                m_lines.push_back(tabX(1) + "{");
				m_lines.push_back(tabX(2) + "pwassertn(index < " + getMemberName(r) + ".size());");
                m_lines.push_back(tabX(2) + "return " + getMemberName(r) + "[index];");
                m_lines.push_back(tabX(1) + "}");
                m_lines.push_back("");
                m_lines.push_back(tabX(1) + "void " + t->name + "::" + r.lowername + "_push(" + getSetterTypeName(r) + " value)");
                m_lines.push_back(tabX(1) + "{");
                m_lines.push_back(tabX(2) + getMemberName(r) + ".push_back(value);");
                m_lines.push_back(tabX(1) + "}");
                m_lines.push_back("");
                m_lines.push_back(tabX(1) + "void " + t->name + "::" + r.lowername + "_size()");
                m_lines.push_back(tabX(1) + "{");
                m_lines.push_back(tabX(2) + getMemberName(r) + ".size();");
                m_lines.push_back(tabX(1) + "}");
                m_lines.push_back("");
                m_lines.push_back(tabX(1) + "void " + t->name + "::" + r.lowername + "_clear()");
				m_lines.push_back(tabX(1) + "{");
				if(r.isTable())
				{
					genClear(tabX(2),r);
				}
				else
				{
					m_lines.push_back(tabX(2) + getMemberName(r) + ".clear();");
				}
				m_lines.push_back(tabX(1) + "}");
                m_lines.push_back("");

                m_lines.push_back(tabX(1) + "void " + t->name + "::" + r.lowername + "_erase(size_t index)");
                m_lines.push_back(tabX(1) + "{");
				m_lines.push_back(tabX(2) + "pwassert(" + getMemberName(r) + ".size() > index);");
				if(r.isTable())
				{
					m_lines.push_back(tabX(2) + "_safe_delete(" + getMemberName(r) + "[index]);");
				}
				m_lines.push_back(tabX(2) + getMemberName(r) + ".erase(m_" + r.lowername + ".begin() + index);");
				m_lines.push_back(tabX(1) + "}");
                m_lines.push_back("");

                m_lines.push_back(tabX(1) + "void " + t->name + "::" + r.lowername + "_reset(const " + getStoreTypeName(r) + "& array)");
                m_lines.push_back(tabX(1) + "{");
				if(r.isTable())
					genClear(tabX(2),r);
                m_lines.push_back(tabX(2) + getMemberName(r) + " = array;");
                m_lines.push_back(tabX(1) + "}");
                m_lines.push_back("");
                m_lines.push_back(tabX(1) + "void " + t->name + "::" + r.lowername + "_set(size_t index," + getSetterTypeName(r) + " value)");
                m_lines.push_back(tabX(1) + "{");
				m_lines.push_back(tabX(2) + "pwassert(" + getMemberName(r) + ".size() > index);");
				if(r.isTable())
					m_lines.push_back(tabX(2) + "_safe_delete(" + getMemberName(r) + "[index]);");
                m_lines.push_back(tabX(2) + getMemberName(r) + "[index] = value;");
                m_lines.push_back(tabX(1) + "}");
            }
        }
    }

	Table* TableGenerator::findTable( const std::string& name )
	{
		for(size_t i = 0; i < m_vAllTables.size(); ++i)
		{
			if(m_vAllTables[i]->name == name)
				return m_vAllTables[i];
		}
		return NULL;
	}

	void TableGenerator::genClear( const std::string& tabs,Field& r )
	{
		m_lines.push_back(tabs + "while(!" + getMemberName(r) + ".empty())");
		m_lines.push_back(tabs + "{");
		m_lines.push_back(tabs + tabX(1) + "_safe_delete(" + getMemberName(r) + ".front());");
		m_lines.push_back(tabs + tabX(1) + getMemberName(r) + ".pop_front();");
		m_lines.push_back(tabs + "}");	
	}



}
