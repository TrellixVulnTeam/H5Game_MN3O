#ifndef PW_GDB_IDL_H
#define PW_GDB_IDL_H

#include <string>
#include <vector>

namespace gdb
{
    class Attrs
    {
    public:
        size_t linenum;
        std::string name;
        std::vector<std::string> args;
    };

    class Field
    {
    public:
        size_t linenum;
        std::string type;
        std::string name;
        std::string lowername;
        std::vector<Attrs> attrs;
    public:
        inline bool isArray()
        {
            return this->find("array") != NULL;
        }

		inline bool isTable()
		{
			return type == "table";
		}
		
		std::string getMetaTableName()
		{
			if(!isTable())
				return "";
			Attrs* a = this->find("meta");
			if(a == NULL || a->args.size() <= 0)
				return "";
			return a->args[0];
		}

        std::vector<std::string>& getOldNames()
        {
            static std::vector<std::string> sv_empty;

            Attrs* a = this->find("oldname");
            if(a != NULL)
                return a->args;
            return sv_empty;
        }
    public:
        Attrs* find(const std::string& name);
    };

    class Table
    {
    public:
        ~Table();
    public:
        std::string name;
        std::vector<Attrs> attrs;
        std::vector<Field*> fields;
    };

}
#endif // PW_GDB_IDL_H
