#include "pw_gdb_idl.h"

namespace  gdb
{
    Attrs* Field::find(const std::string& name)
    {
        for(size_t i = 0; i < this->attrs.size(); ++i)
        {
            if(this->attrs[i].name == name)
                return &attrs[i];
        }
        return NULL;
    }
}
