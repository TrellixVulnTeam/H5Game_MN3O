/* -*- C++ -*- */
// $Id: ACE_Init_Test.h 80826 2008-03-04 14:51:23Z wotte $

// ============================================================================
//
// = LIBRARY
//    tests
//
// = FILENAME
//    ACE_Init_Test.h
//
// = DESCRIPTION
//   Main header file for the ACE_INIT_TEST application.
//
// = AUTHOR
//    Steve Huston <shuston@cs.wustl.edu>
//
// ============================================================================

#ifndef AFX_ACE_INIT_TEST_H__64FDC9FE_F7F9_11D2_89B6_00A024CC68DB__INCLUDED_
#define AFX_ACE_INIT_TEST_H__64FDC9FE_F7F9_11D2_89B6_00A024CC68DB__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
  #error include 'stdafx.h' before including this file for PCH
#endif

#include "ACE_Init_Test_Resource.h" // main symbols

class CACE_Init_TestApp : public CWinApp
{
  // = TITLE
  //   See ACE_Init_Test.cpp for the implementation of this class
public:
  CACE_Init_TestApp (void);

  // Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CACE_Init_TestApp)
public:
  virtual BOOL InitInstance();
  //}}AFX_VIRTUAL

  // Implementation

  //{{AFX_MSG(CACE_Init_TestApp)
  // NOTE - the ClassWizard will add and remove member functions here.
  //    DO NOT EDIT what you see in these blocks of generated code !
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif /* !defined(AFX_ACE_INIT_TEST_H__64FDC9FE_F7F9_11D2_89B6_00A024CC68DB__INCLUDED_) */
